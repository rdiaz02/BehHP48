/***************************************************************************
    copyright            : (C) 1996, 2004 by Ram�n D�az-Uriarte
    email                : rdiaz@ligarto.org
***************************************************************************/


/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with this program; if not, write to the Free Software            * 
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307,USA *
 *                                                                         *
 **************************************************************************/






/* This program takes the HP files from experiments 2 and 3 and
produces output for checking.  When the files are checked, they can
be processed with antipb.cpp. This is very similar to antip3,
but the program has been very simplified, because there is no
nesting in the antipredator questions.  There are also
changes in the header file (antipa.h), both in the classes
used and in the behavioral codes.
Note that to use this program, you need to use the word macro
"FocaltoC", included as a comment at the end of the antipa.h
file
 */



#include "antipa.h"
/* antipa.h defines the classes used (Initial, All_Antipred, Total_Event,
Pre_Treatment), the functions behav_conv and getvar. */


main (int argc, char *argv[])
{

	// Command line arguments and error handling of files.
	if(argc!=4) {cout <<"antip1 input output error"; return 1;}
	ifstream d1(argv[1], ios::in | ios::binary);
	if(!d1) {cout << "Cannot open input file"; return 1;}
	ofstream out(argv[2]);
	if(!out) {cout <<"Cannot open output file"; return 1;}
	ofstream error_file(argv[3]);
	if(!error_file) {cout <<"Cannot open error file"; return 1;}


	/* All are temporal variables. First three for initial input; next
		for no access; next two for continuous event. */
	char caca[30], first_thing[30], type_data[30], tecla[30],
		t2[30], separator[30];
	double hora; //Temporal var. in continuous event part.

	int register j,k;


	//Main loop

	strcpy(caca,"xx"); //Anything except $ would work here.
	cout <<'\n';
	cout <<"New run\n";
	while(strcmp(caca,"$")) {

		All_Antipr Ant;
		Total_Event EV;

		d1 >> first_thing;
		if(strcmp(first_thing,"\"%%%%%\"")) {cout <<"Error: no %%%%%" << '\n'; exit(1);}
		d1>>type_data;
		if(strcmp(type_data,"\"EXP_1\"")) {cout <<"Error: no EXP_1" << '\n'; exit(1);}
		d1>>Ant.fecha;
		getvar(Ant.ID,d1,Ant.ID);
		getvar(Ant.ID,d1,Ant.Enclosure);
		getvar(Ant.ID,d1,Ant.Temp_Ground);
		getvar(Ant.ID,d1,Ant.Temp_Air);
		getvar(Ant.ID,d1,Ant.Treatment);
		getvar(Ant.ID,d1,Ant.Init_Substrate);
		getvar(Ant.ID,d1,Ant.Init_SunPosition);



		// Here is where the "continuous event recording" starts.

		strcpy(tecla,"xxxx");hora = -99;//initialization
		j=0;
		for (int vueltas=0; vueltas <3; vueltas ++) {
		/* This loop runs 3 times: one for focal, one for approach1,and
		one for antipredator */

			getvar(Ant.ID,d1,EV.Section[vueltas]);
			cout<<EV.Section[vueltas]<<'\n';
			//Follwoing loop takes care of continuous data.
			do {
			d1 >> tecla >> t2;
			hora=atof(t2);
			if(strlen(tecla)>4) {cout<<"Fatal error: tecla has wrong format. ID " << Ant.ID << " behavior " << j+1 <<" date "<<Ant.fecha<< '\n'; exit(1);}
			behav_conv(tecla);
			strcpy(EV.tempfile[j].behav,tecla);
			if( (!vueltas) && (!strcmp(EV.tempfile[j].behav,"My move")))
				strcpy(EV.tempfile[j].behav,"Start");
			EV.tempfile[j].hora = hora;
//xx:???check??		cout<<j<<" "<<EV.tempfile[j].behav<<" "<<EV.tempfile[j].hora<<'\n';
			j+=1;
			if(j>300) { cout<<"Fatal error: exceeded size of structure. Behav "<<EV.tempfile[j].behav<<" "<<" hora " <<EV.tempfile[j].hora<<'\n'; exit(1); }
			}
			while (strcmp(tecla,"End"));
		}



// Questions that come after the continuous event recording part.

		getvar(Ant.ID,d1,Ant.Focal_LO_Position);
		getvar(Ant.ID,d1,Ant.Focal_Sun_LO);
		getvar(Ant.ID,d1,Ant.Antipred_Data_Present);
		/* Is there any antipr. data? If there isn't (because this
		is just a focal obs. file) get only weather,
		and make other vars. "Not applicable"'s.*/

		if(!strcmp(Ant.Antipred_Data_Present,"No"))
			{
			d1>>caca;d1>>caca;d1>>caca;d1>>caca;
			d1>>caca;d1>>caca;d1>>caca;
			getvar(Ant.ID,d1,Ant.Weather);
			Ant.antipr_runs=0;
			strcpy(Ant.Approach_Distance,"Not Applicable");
			strcpy(Ant.Flight_Straight,"Not Applicable");
//			strcpy(Ant.LO_Position,"Not Applicable");
			strcpy(Ant.Conspic_LO,"Not Applicable");
			strcpy(Ant.Type_LO,"Not Applicable");
			strcpy(Ant.Hiding_Type,"Not Applicable");
			strcpy(Ant.Hiding_Behav,"Not Applicable");
			strcpy(Ant.Reemerges,"Not Applicable");
			strcpy(Ant.Same_diff_Loc_Reemerg,"Not Applicable");
			strcpy(Ant.D_my_O_my_D,"Not Applicable");
			strcpy(Ant.Focal_Returned_Perch,"Not Applicable");
			strcpy(Ant.Intruder_Bobs,"Not Applicable");
			strcpy(Ant.Intruder_Attacks,"Not Applicable");
			strcpy(Ant.Intruder_Bites,"Not Applicable");
			strcpy(Ant.Intruder_SVL,"Not Applicable");
			strcpy(Ant.Intruder_ID,"Not Applicable");
			strcpy(Ant.Focal_SVL,"Not Applicable");
			}

//If there is Antipr. info, here comes the data reading.
		if(!strcmp(Ant.Antipred_Data_Present,"Si"))
			{
			d1.get(caca,2);
			if(strcmp(caca," ")) {cout<< "error in 2" <<'\n'; exit(1);}
			d1.get(separator,2);
			Ant.antipr_runs=atoi(separator);
			getvar(Ant.ID,d1,Ant.D_my_O_my_D);
			getvar(Ant.ID,d1,Ant.Approach_Distance);
			getvar(Ant.ID,d1,Ant.Flight_Straight);
			getvar(Ant.ID,d1,Ant.Conspic_LO);
			getvar(Ant.ID,d1,Ant.Type_LO);
			getvar(Ant.ID,d1,Ant.Hiding_Type);
			getvar(Ant.ID,d1,Ant.Closest_to_Focal);
			getvar(Ant.ID,d1,Ant.Hiding_Behav);
			getvar(Ant.ID,d1,Ant.Reemerges);
			getvar(Ant.ID,d1,Ant.Same_diff_Loc_Reemerg);
			getvar(Ant.ID,d1,Ant.Exposure_Reemerg);
			getvar(Ant.ID,d1,Ant.Focal_Returned_Perch);
			getvar(Ant.ID,d1,Ant.Intruder_Bobs);
			getvar(Ant.ID,d1,Ant.Intruder_Attacks);
			getvar(Ant.ID,d1,Ant.Intruder_Bites);
			getvar(Ant.ID,d1,Ant.Intruder_SVL);
			getvar(Ant.ID,d1,Ant.Intruder_ID);
			getvar(Ant.ID,d1,Ant.Focal_SVL);
			getvar(Ant.ID,d1,Ant.Weather);
			}


//  *****************************************************************
//  *********************** OUTPUT CODE *****************************
//  *****************************************************************


		out << "ID: " << Ant.ID<<'\n';
		out <<"Date: "<<Ant.fecha<<'\n';
		out<<"Time: ";out.precision(4);out<<EV.tempfile[0].hora<<'\n';
		out<<"Enclosure: "<<Ant.Enclosure<<'\n';
		out <<"Temp.Ground: "<<Ant.Temp_Ground<<'\n';
		out <<"Temp.Air: " <<Ant.Temp_Air<<'\n';
		out <<"Treatment:" <<Ant.Treatment<<'\n';
		out <<"Initial Substrate: "<<Ant.Init_Substrate<<'\n';
		out <<"Initial Sun: "<<Ant.Init_SunPosition<<'\n';


		/* Output the continuous event recording part
		(the "focal like") data. */
		//First, output the heading.
		out<<'\n';
		out.width(20);
		out.setf(ios::left);
		out<<"Behavior";
		out.width(12);
		out<<"Time";
		out.width(13);
		out<<"Comments"<<'\n';

		k=0;
		for (int vueltas = 0; vueltas < 3; vueltas ++) {
			out<<"**"<<EV.Section[vueltas]<<"**"<<'\n';
			do {
				out.precision(7);
				out.width(20);
				out.setf(ios::left);
				out << EV.tempfile[k].behav;
				out.width(12);
				out << EV.tempfile[k].hora;
				out.width(13);
				out<<"-"<<'\n';

			k+=1;
			} while(strcmp(EV.tempfile[k-1].behav,"End"));
		}
		out <<"#" <<'\n';
		/* The # separates the continuous event recording from the
			antipredator measures. */



		out.width(35);out<<"INTRUDER AND ANTIPREDATOR"<<'\n';
		out.width(35); out<<"FOCAL PART: Location   "<<Ant.Focal_LO_Position<<'\n';
		out.width(35); out<<"FOCAL PART: Sun        "<<Ant.Focal_Sun_LO<<'\n';
		out.width(35);out<< "Number of runs measured"<<Ant.antipr_runs<<'\n';
		out.width(35); out<<"Approach distance      "<<Ant.Approach_Distance<<'\n';
		out.width(35); out<<"Closest App.distance   "<<Ant.Closest_to_Focal<<'\n';
		out.width(35); out<<"Escape straight/curved "<<Ant.Flight_Straight<<'\n';
//		out.width(35); out<<"LO_Position            "<<Ant.LO_Position <<'\n';
		out.width(35); out<<"Conspic. LO            "<<Ant.Conspic_LO<<'\n';
		out.width(35); out<<"Type LO                "<<Ant.Type_LO<<'\n';
		out.width(35); out<<"Hiding Type            "<<Ant.Hiding_Type<<'\n';
		out.width(35); out<<"Hiding Behav           "<<Ant.Hiding_Behav      <<'\n';
		out.width(35);out<< "Reemerges?             " <<Ant.Reemerges<<'\n';
		out.width(35); out<<"Same/diff. loc. Reemer "<<Ant.Same_diff_Loc_Reemerg      <<'\n';
		out.width(35); out<<"Exposure Reemergence   "<<Ant.Exposure_Reemerg <<'\n';
		out.width(35); out<<"Dist.my.Origin.my.Dest "<<Ant.D_my_O_my_D    <<'\n';
		out.width(35); out<<"Focal Return to Perch? "<<Ant.Focal_Returned_Perch<<'\n';
		out.width(35); out<<"Intruder Bobs?         "<<Ant.Intruder_Bobs       <<'\n';
		out.width(35); out<<"Intruder Attacks?      "<<Ant.Intruder_Attacks    <<'\n';
		out.width(35); out<<"Intruder Bites?        "<<Ant.Intruder_Bites      <<'\n';
		out.width(35); out<<"Intruder's SVL         "<<Ant.Intruder_SVL        <<'\n';
		out.width(35); out<<"Intruder's ID          "<<Ant.Intruder_ID         <<'\n';
		out.width(35); out<<"Focal SVL              "<<Ant.Focal_SVL           <<'\n';
		out.width(35); out<<"Weather                "<<Ant.Weather             <<'\n';

// The following variables I do not collect with HP, but write on paper.
		out.width(35); out<<"Female out when antip? "<<'\n';
		out.width(35); out<<"Female's time out      "<<'\n';
		out.width(35); out<<"Female's time full exp "<<'\n';
		out.width(35); out<<"Initial female height  "<<'\n';
		out.width(35); out<<"Initial male height    "<<'\n';
		out.width(35); out<<"Dist. start-enclosure  "<<'\n';
		out.width(35); out<<"Second app: ADistance  "<<'\n';
		out.width(35); out<<"Second app: CDistance  "<<'\n';
/* Second app: it refers to my approach to the enclosure after
the 20' of waiting; I had to approach the enclosure to minimize
them habituating.  This way, at end of trial I kind of reinforzed
that I was, really, a mean predator. I recorded appraoch distance,
and closest distance (also # runs, but not included here). */
		out <<"%" <<'\n' << '\n'; //The % separates the records of different animals.

		d1.getline(caca,2);
		}

	out.close();
	d1.close();
	error_file.close();
	cout <<"Normal termination\n";
	return 0;}






