/***************************************************************************
    copyright            : (C) 1996, 2004 by Ram�n D�az-Uriarte
    email                : rdiaz@ligarto.org
***************************************************************************/


/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with this program; if not, write to the Free Software            * 
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307,USA *
 *                                                                         *
 **************************************************************************/







#include <stdio.h>
#include <stdlib.h>
#include "antipb.h"


char caca[101], temporal [50],s1[15],s2[15];
int indicador;

void read_init_stuff(ifstream &d1, All_Antipr &ALA );
void getinit(ifstream &d1,char *variable);
double hora_dec(const double &num);
void heading0(ostream &out);
void heading3(ostream &out);
void antip_data_in(ifstream &d1, All_Antipr &AAP);
void read_cont_event(ifstream &d1, cont_event &event_struct, Antipred_CE_Stuff &Adat);
void dataout(ofstream &out,All_Antipr &AAP, Antipred_CE_Stuff &Adat);


main (int argc, char *argv[])
{

// Command line arguments and error handling of files.

if(argc!=3) {cout <<"antip2 input output"; return 1;}
ifstream d1(argv[1], ios::in | ios::binary);
if(!d1) {cout << "Cannot open input file"; return 1;}
ofstream out(argv[2]);
if(!out) {cout <<"Cannot open output file"; return 1;}




/*
if(argc!=4) {cout <<"antip2 input output1 output2"; return 1;}
ifstream d1(argv[1], ios::in | ios::binary);
if(!d1) {cout << "Cannot open input file"; return 1;}
ofstream out(argv[2]);
if(!out) {cout <<"Cannot open output file"; return 1;}

ofstream error_file(argv[3]);
if(!error_file) {cout <<"Cannot open error file"; return 1;}
*/

// Create the heading for the output file.  Each file handles different parts.

heading0(out);
heading3(out);
indicador =0;

int next_char; // to end main loop.
int j; //a loop counter.
//This is the main loop

do {
j = 0;
//cont_event eventarray[SIZE_EVENTARRAY];

	cont_event *eventptr;
	eventptr = new cont_event [300];
	if(!eventptr) {
		cout <<"allocation failure\n";
		exit(1);}
	/* To be able to work with very large files,
	I use a array of pointers, instead of the array
	of the structure directly. */

/* As I am still unsure of this, recheck the program, without the
pointer.  Comment out the pointer lines, and uncomment the
cont_evetn eventarray line.  Then, replace all "eventptr" for
"eventarray". */


	Antipred_CE_Stuff Adat;
	All_Antipr ANTP;

	//First, get the initial information.

	read_init_stuff(d1,ANTP); //ID, temp, weather, etc.

	do {

		read_cont_event(d1,eventptr[j],Adat); //Reads continuous event data,
							//and compute time in seconds since 00:00.

		Adat.Time_to_Attack(eventptr[j].behav, eventptr[j].hora_std);
		Adat.Time_Reemergence(eventptr[j].behav, eventptr[j].hora_std);
		Adat.Duration_Approach(eventptr[j].behav,eventptr[j].hora_std);
		j+=1;
		if(j>300) { cout<<"Fatal error: exceeded size of structure. Behav "<<eventptr[j].behav<<" "<<" hora " <<eventptr[j].hora<<'\n'; exit(1); }

	}  while(!(Adat.Flag_Antip==1 && !strcmp(eventptr[j-1].behav,"End               ")));

//	Adat.Duration_Approach();
	antip_data_in(d1, ANTP); //Read antipredator data.

	dataout(out,ANTP, Adat);
	delete [] eventptr;

		/* If file is over, there will be a (generally variable) number of
		carriage returns, and eventually a EOF.  d1.peek will return -1
		if it finds EOF.  If the file is not over, there will be a bunch
		of empty lines, and eventually a "ID: "; when peek sees "I" it returns
		73. What these lines do is keep reading (discarding) lines until
		either a "I" or a EOF is found. */
	next_char = d1.peek();
	while ((next_char != 73) && (next_char != -1)) {
		d1.getline(caca,90);
		next_char = d1.peek();}


	indicador +=1;
	cout<<"Processing data file "<<indicador<<'\n';

} while (next_char != -1);

out.close();
d1.close();
//error_file.close();

cout <<"Normal termination\n";
return 0;
}



void getinit(ifstream &d1, char * variable)
{
char caca[80];
d1.getline(caca,100,':');
d1.getline(caca,2);
d1.get(variable,90,'\r');
}

double hora_dec(const double &num)
/* This function takes a number in standard HH.mmssss format
	(the HP format) and returns the time in seconds since 00:00:00.00 */
{
  char *str;
  int dec, sign, ndig = 6;
  long int horas, minutos, segundos,decimas;
  char horasstring[2], minutosstring[2],segundosstring[2],decimasstring[4];
  int i, j, l;

  str = fcvt(num, ndig, &dec, &sign);

  for (i=0; i < dec; i++) horasstring[i]=str[i];
  j=i;
  for(j;j<=2;j++) horasstring[j]='\0';
  horas=atoi(horasstring);

  l=0;
  for(i; i < dec+2; i++, l++) minutosstring[l]=str[i];
  minutosstring[2]='\0';
  minutos=atoi(minutosstring);

  l=0;
  for(i;i < dec+4; i++,l++) segundosstring[l]=str[i];
  segundosstring[2]='\0';
  segundos=atoi(segundosstring);

  l=0;
  for(i;i < dec+6; i++,l++) decimasstring[l]=str[i];
  decimasstring[2]='\0';
  decimas=atoi(decimasstring);

  double newh=(horas * 3600) + (minutos * 60) + segundos +
		((long double) decimas/100);
  return newh;

}




void read_cont_event(ifstream &d1, cont_event &event_struct,
							Antipred_CE_Stuff &Adat )
{
	d1.getline(event_struct.behav,19);
	if(!strcmp(event_struct.behav,"**ANTIP**\r")) {
		Adat.Flag_Antip=1;
		Adat.Flag_Focal=0;
		Adat.Flag_Intru=0;}
	else if(!strcmp(event_struct.behav,"**FOCAL**\r")) {
		Adat.Flag_Focal=1;
		Adat.Flag_Antip=0;
		Adat.Flag_Intru=0;}
	else if(!strcmp(event_struct.behav,"**INTRU**\r")) {
		Adat.Flag_Intru=1;
		Adat.Flag_Focal=0;
		Adat.Flag_Antip=0;}
	else {
		d1.get(temporal,12);
		event_struct.hora=atof(temporal);
		event_struct.hora_std=hora_dec(event_struct.hora);
		d1.getline(caca,90);}
}

void read_init_stuff(ifstream &d1, All_Antipr &ALA )  //xx: toda vas checked OK
{
	d1.getline(caca,30,':');
	d1.getline(caca,2);
	d1.getline(ALA.ID,5);
//	getinit(d1,ALA.ID2);
//XX: en el futuro, checkear que ID y ID2 son iguales!!!

	getinit(d1,ALA.Fecha);
	getinit(d1,ALA.Hora);
	getinit(d1,ALA.Enclosure);
	getinit(d1,ALA.Temp_Ground);
	getinit(d1,ALA.Temp_Air);
	d1.getline(caca,100,':');
	d1.get(ALA.Treatment,90,'\r');
	getinit(d1,ALA.Init_Substrate);
	getinit(d1,ALA.Init_SunPosition);
	d1.getline(caca,100); //The empty line.
	d1.getline(caca,100); //The heading for the behaviors.
}




void antip_data_in(ifstream &d1, All_Antipr &AAP)  //checked vars OK
{
strcpy(s1,"");
strcpy(s2,"");
strcpy(AAP.AD_b,"0");
strcpy(AAP.CD_b,"0");

/* Right now, I only extract some of the information contained in
the last part of each animal's file. All other lines are not dealt with
now, so I use the "getline(caca,90)".  The information that is curretnly
extracted has more meaningful names. */


	d1.getline(caca,90); //The "#" and carriage return after the cont. event. recording.
	d1.getline(caca,90);
	d1.getline(caca,90);
	d1.getline(caca,90);
//Next four lines extract number of runs.
	d1.getline(caca,35);
	d1.getline(temporal,30);
	AAP.antipr_runs=atoi(temporal);
	d1.getline(caca,36);
	d1.get(s1,2);
	do {
	    d1.get(s2,2);
	    if( strcmp(s2,"+") && strcmp(s2,"\r") ) strcat(s1,s2);
	} while(strcmp(s2,"\r") && strcmp(s2,"+"));
	if(!strcmp(s2,"+")) { d1.get(AAP.AD_b,90,'\r');d1.getline(caca,30);}
	else d1.getline(caca,30);
	strcpy(AAP.AD_a,s1);
	if(!strcmp("RG",AAP.AD_b)) strcpy(AAP.AD_b,"1.7");
	if(!strcmp("RP",AAP.AD_b)) strcpy(AAP.AD_b,"1.7");
	strcpy(s1,"");
	strcpy(s2,"");
	d1.getline(caca,36);
	d1.get(s1,2);
	do {
	    d1.get(s2,2);
	    if( strcmp(s2,"+") && strcmp(s2,"\r") ) strcat(s1,s2);
	} while(strcmp(s2,"\r") && strcmp(s2,"+"));
	if(!strcmp(s2,"+")) {d1.get(AAP.CD_b,90,'\r');d1.getline(caca,30);}
	else d1.getline(caca,30);
	strcpy(AAP.CD_a,s1);
	if(!strcmp("RG",AAP.CD_b)) strcpy(AAP.CD_b,"1.7");
	if(!strcmp("RP",AAP.CD_b)) strcpy(AAP.CD_b,"1.7");
	d1.getline(caca,90);
	d1.getline(caca,90);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
//	d1.getline(AAP.Reemerges,20);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
	d1.getline(caca,96);
}



// PRINTING OUT FUNCTIONS:
// First, the functions to create the heading.
// all are checked OK xx

void heading0(ostream &out)
{
	out.setf(ios::left);
	out<<setw(13)<< "Bicho";
	out<<setw(13)<<"Fecha";
	out<<setw(13)<<"Hora";
	out<<setw(13)<<"Encl";
	out<<setw(13)<<"Trt";
//	out<<setw(13)<<"Intr";
	out<<setw(13)<<"Temp";
}

void heading3(ostream &out)
{
	out.setf(ios::left);
	out.setf(ios::fixed);
	out<<setw(13)<<"AD(a)";
	out<<setw(13)<<"AD(b)";
//	out<<setw(13)<<"ADist";
	out<<setw(13)<<"CD(a)";
	out<<setw(13)<<"CD(b)";
//	out<<setw(13)<<"CDist";
	out<<setw(13)<<"TOut";
	out<<setw(13)<<"TFull";
	out<<setw(13)<<"TAttack";
	out<<setw(13)<<"DurmyAppr";
	out<<'\n';
}

void dataout(ofstream &out,All_Antipr &AAP,Antipred_CE_Stuff &Adat)
//checked OK
{
	out.setf(ios::left);
	out<<setw(13)<<AAP.ID;
	out<<setw(13)<<AAP.Fecha;
	out<<setw(13)<<AAP.Hora;
	out<<setw(13)<<AAP.Enclosure;
	out<<setw(13)<<AAP.Treatment;
//	out<<setw(13)<<AAP.Intruder_ID;
	out<<setw(13)<<AAP.Temp_Air;
	out<<setw(13)<<AAP.AD_a;
	out<<setw(13)<<AAP.AD_b;
	out<<setw(13)<<AAP.CD_a;
	out<<setw(13)<<AAP.CD_b;
	out.precision(2);
	out<<setw(13)<<Adat.Time_to_Reemergence;
	out.precision(2);
	out<<setw(13)<<Adat.Time_to_Full_Exposure;
	out.precision(2);
	out<<setw(13)<<Adat.Time_to_1stAttack;
	out.precision(5);
	out<<setw(13)<<Adat.Duration_my_Approach;
//	out.precision(2);
//	out<<Num_Runs;
	out<<'\n';
}



