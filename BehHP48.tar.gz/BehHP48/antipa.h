/***************************************************************************
    copyright            : (C) 1996, 2004 by Ram�n D�az-Uriarte
    email                : rdiaz@ligarto.org
***************************************************************************/


/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with this program; if not, write to the Free Software            * 
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307,USA *
 *                                                                         *
 **************************************************************************/




#include <fstream.h>
#include <string.h>
#include <iomanip.h>
#include <stdlib.h>





/* This structure contains ALL of the antipredator data EXCEPT those
that need to be obtained from the continuous event recording.
It is very similar to the structure in the file antip20.h but not
exactly the same!! */

class All_Antipr{
	public:
	 char ID[30],Enclosure[30],Temp_Ground[30],Temp_Air[30],
	      Treatment[30],Init_Substrate[30],Init_SunPosition[30],
	      D_my_O_my_D[30], Approach_Distance[30], Flight_Straight[30],
	      Conspic_LO[30], Type_LO[30],Hiding_Type[30], Closest_to_Focal[30],
	      Hiding_Behav[30], Reemerges[30], Same_diff_Loc_Reemerg[30],
	      Exposure_Reemerg[30], Focal_Returned_Perch[30],
	      Focal_LO_Position[30],Focal_Sun_LO[30],
	      Intruder_Bobs[30], Intruder_Attacks[30],Intruder_Bites[30],
			Intruder_SVL[30], Intruder_ID[30], Focal_SVL[30],Weather[30],
			fecha[30], Antipred_Data_Present[30];


	 int antipr_runs; /* Number of antipr. runs, or number of
				  escapes; different from previous versions! */
//	 double fecha;
	 All_Antipr();
};


All_Antipr::All_Antipr()
// Initialices antipr_runs and helps catch errors.
{
//	fecha = -99999.99;
	antipr_runs = -99;
	strcpy(fecha,"ERROR!!");
//	strcpy(Antipred_Data_Present,"ERROR!");
	strcpy(ID,"ERROR!!");
	strcpy(Enclosure,"ERROR!!");
	strcpy(Temp_Ground,"ERROR!!");
	strcpy(Temp_Air,"ERROR!!");
	strcpy(Treatment,"ERROR!!");
	strcpy(Init_Substrate,"ERROR!!");
	strcpy(Init_SunPosition,"ERROR!!");
	strcpy(Weather,"ERROR!!");
	strcpy(Approach_Distance,"ERRORR!!");
	strcpy(Flight_Straight,"ERRORR!!");
	strcpy(Focal_LO_Position,"ERRORR!!");
	strcpy(Focal_Sun_LO,"ERRORR!!");
//	strcpy(LO_Position,"ERROR!!");
	strcpy(Conspic_LO,"ERRORR!!");
	strcpy(Type_LO,"ERRORR!!");
	strcpy(Hiding_Type,"ERRORR!!");
	strcpy(Hiding_Behav,"ERRORR!!");
	strcpy(Reemerges,"ERRORR!!");
	strcpy(Same_diff_Loc_Reemerg,"ERRORR!!");
	strcpy(D_my_O_my_D,"ERRORR!!");
	strcpy(Focal_Returned_Perch,"ERRORR!!");
	strcpy(Intruder_Bobs,"ERRORR!!");
	strcpy(Intruder_Attacks,"ERRORR!!");
	strcpy(Intruder_Bites,"ERRORR!!");
	strcpy(Intruder_SVL,"ERRORR!!");
	strcpy(Intruder_ID,"ERRORR!!");
	strcpy(Focal_SVL,"ERRORR!!");

}


class Total_Event {

	struct behav_time {
		char behav[30];
		double hora;
	};
	public:
	char Section[3][70];
	//Section can be of three types: Focal, Appr_1, and Antip.
	behav_time tempfile[300];
	Total_Event();
};

Total_Event::Total_Event() {
	for(int i=0;i<3;i++)	strcpy(Section[i],"ERROR!!");
	for(int j=0;j<300;j++) {
		tempfile[j].hora = -99;
		strcpy(tempfile[j].behav,"ERROR!!"); }
}




char *behav_codes[][2] = {

	"41.1", "Bob",
	"46.1", "Poke",
	"21.1", "High-Intens Displ",
	"31.1", "Gular Bob",
	"26.1", "Lick",
	"44.1", "Tail Flip",
	"24.1", "Tail Move",
	"72.1", "4 Legs",
	"25.1", "Bite",
	"45.1", "Attack",
	"15.1", "Courtship",
	"13.1", "Copulation",
	"11.1", "Arching back",
	"16.1", "Arching + Tail",
	"12.1", "Caudal present.",
	"42.1", "Movement",
	"62.1", "Eating",
	"63.1", "Shiting",
	"64.1", "Lost",
	"65.1", "Found",
	"84.1", "3 Legs",
	"14.1", "Basking",
	"22.1", "Orientation",
	"32.1", "Normal posture",
	"65.3", "End",
	"92.1", "Start/My move",
	//"52.1", "Stop Lizard", Haven't really used it.
	"53.1", "Lost Lizard",
	"94.1", "No access",
	// "23.1", "Intruder runs",
	// "43.1", "Intruder hides",
	"82.1", "Bicho dentro",
	"83.1", "Intruder back",
	"93.1", "Start remove intr",
	"95.1", "Perdido en app. 1",
	"85.1", "Full exposure",
	"36.1", "Back in position",
	"75.3", "End(1)", 		//this used when I was still measuring behind blind
	"22.3", "I'm behind blind"	//and didn't want to press 65.3; so I pressed 75.3,
					// which didn't stop program, and pressed 22.3 for
					//behind blind.
};

void behav_conv(char *str)
{
	int register i;
	for (i=0; behav_codes[i][0]; i++)
		if(! strcmp(behav_codes[i][0], str)) strcpy (str, behav_codes[i][1]);
}

void getvar(char *ID, ifstream &d1,char *variable)
// ID is passed just to give the ID as output in case of error.
{
	char caca[70];
	d1.getline(caca,70,'\"');
	if(strcmp(caca," ")) {cout<< "error in variable " <<variable<<" for ID "<<ID<<'\n'; exit(1);}
	d1.getline(variable,70,'\"');
}


/* This is the macro "FocaltoC" that needs to be run
on every file prior to use of the program antipa.exe.

The best thing is to put all the files together (by inserting successive
files into the first), and then to run the macro. Save that, and
run antipa.

Public Sub MAIN()
WordBasic.LineUp 3
WordBasic.EditReplace Find:="%%HP: T(3)A(D)F(.);", Replace:=Chr(34) + "%%%%%" + Chr(34), Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.LineUp 3

WordBasic.EditReplace Find:=Chr(34) + "End Focal ##" + Chr(34), Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:=Chr(34) + "## End Adlib" + Chr(34), Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:=Chr(34) + "## End Posit" + Chr(34), Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:=Chr(34) + "End Antip ##" + Chr(34), Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1

WordBasic.EditReplace Find:="{ ", Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:="}", Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:="{", Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "T:" + Chr(34), Replace:="", Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Loc:" + Chr(34), Replace:="", Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2

WordBasic.EditReplace Find:=Chr(34) + "Weather ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Wind ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "ID ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Substrate ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Sun Pos ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Height ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Loc: ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2

WordBasic.EditReplace Find:=Chr(34) + "@" + Chr(34), Replace:="92.1", Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Temp= ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2

WordBasic.EditReplace Find:=Chr(34) + "Head ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Conspic ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Dist. hide ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Type clos. hyde ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Type close hyde ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Start, End ", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "Seen used", Replace:=Chr(34), Direction:=0, MatchCase:=1, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2

WordBasic.EditReplace Find:=Chr(34) + "#" + Chr(34) + " ", Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1

WordBasic.EditReplace Find:="^p^p", Replace:="^p", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="^p^p", Replace:="^p", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="^p^p", Replace:="^p", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="^p^p", Replace:="^p", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="^p^p", Replace:="^p", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="^p^p", Replace:="^p", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="^p", Replace:=" ", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="  ", Replace:=" ", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="  ", Replace:=" ", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="  ", Replace:=" ", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:="  ", Replace:=" ", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EditReplace Find:=" ^p", Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=" ^p", Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=2
WordBasic.EditReplace Find:=Chr(34) + "#" + Chr(34) + " ", Replace:="", Direction:=0, MatchCase:=0, WholeWord:=0, PatternMatch:=0, SoundsLike:=0, ReplaceAll:=1, Format:=0, Wrap:=1
WordBasic.EndOfDocument
WordBasic.Insert "$$$"
End Sub

************END OF MACRO************
*/
