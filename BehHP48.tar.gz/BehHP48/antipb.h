/***************************************************************************
    copyright            : (C) 1996, 2004 by Ram�n D�az-Uriarte
    email                : rdiaz@ligarto.org
***************************************************************************/


/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with this program; if not, write to the Free Software            * 
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307,USA *
 *                                                                         *
 **************************************************************************/




// File antipb.h.


/* This file has been modified from antip20.h.  It has added a few things,
but mainly has deleted a lot of stuff, in particular functions.


Deleted from class Antipred_CE_Stuff:
	Num_Escapes
	OTPAT
	Displays_Antip
	Start_Focal_Hour
	Check_Reemergence
	Check_num_escapes
	Check_NDisplAntip
	Check_times.


Deleted Focal class and all functions.

Deleted antipredatorloop

Structure All_Antip is taken from antipa.h (which is different from
	the one origianlly in antip20.h.


Many of these function will be needed in the future, for example to calculate
number of displays.

*/





#include <fstream.h>
#include <string.h>
#include <iomanip.h>
#include <stdlib.h>

struct cont_event {
	char behav[19];
	double hora;
	double hora_std;
/*	char Location[14];
	char Height[9];
	char Substrate[13];
	char Comments[400]; */};



/* This structure contains ALL of the antipredator data EXCEPT those
that need to be obtained from the continuous event recording. */



/* This structure contains ALL of the antipredator data EXCEPT those
that need to be obtained from the continuous event recording.
It is very similar to the structure in the file antip20.h but not
exactly the same!! */

class All_Antipr{
	public:
	 char ID[30],Enclosure[30],Temp_Ground[30],Temp_Air[30],
			Treatment[30],Init_Substrate[30],Init_SunPosition[30],
			D_my_O_my_D[30], Approach_Distance[30], Flight_Straight[30],
			Conspic_LO[30], Type_LO[30],Hiding_Type[30], Closest_to_Focal[30],
			Hiding_Behav[30], Reemerges[30], Same_diff_Loc_Reemerg[30],
			Exposure_Reemerg[30], Focal_Returned_Perch[30],
			Focal_LO_Position[30],Focal_Sun_LO[30],
			Intruder_Bobs[30], Intruder_Attacks[30],Intruder_Bites[30],
			Intruder_SVL[30], Intruder_ID[30], Focal_SVL[30],Weather[30],
			Fecha[30], Antipred_Data_Present[30], Hora[30],
			AD_a[30],AD_b[30],CD_a[30],CD_b[30]
			;
//Note: hora has been added; not in the all-antipr class for antipa.

	 int antipr_runs; /* Number of antipr. runs, or number of
				  escapes; different from previous versions! */
//	 double fecha;
	 All_Antipr();
};


All_Antipr::All_Antipr()
// Initialices antipr_runs and helps catch errors.
{
//	fecha = -99999.99;
	antipr_runs = -99;
	strcpy(Fecha,"ERROR!!");
//	strcpy(Antipred_Data_Present,"ERROR!");
	strcpy(ID,"ERROR!!");
	strcpy(Enclosure,"ERROR!!");
	strcpy(Temp_Ground,"ERROR!!");
	strcpy(Temp_Air,"ERROR!!");
	strcpy(Treatment,"ERROR!!");
	strcpy(Init_Substrate,"ERROR!!");
	strcpy(Init_SunPosition,"ERROR!!");
	strcpy(Weather,"ERROR!!");
	strcpy(Approach_Distance,"ERRORR!!");
	strcpy(Flight_Straight,"ERRORR!!");
	strcpy(Focal_LO_Position,"ERRORR!!");
	strcpy(Focal_Sun_LO,"ERRORR!!");
//	strcpy(LO_Position,"ERROR!!");
	strcpy(Conspic_LO,"ERRORR!!");
	strcpy(Type_LO,"ERRORR!!");
	strcpy(Hiding_Type,"ERRORR!!");
	strcpy(Hiding_Behav,"ERRORR!!");
	strcpy(Reemerges,"ERRORR!!");
	strcpy(Same_diff_Loc_Reemerg,"ERRORR!!");
	strcpy(D_my_O_my_D,"ERRORR!!");
	strcpy(Focal_Returned_Perch,"ERRORR!!");
	strcpy(Intruder_Bobs,"ERRORR!!");
	strcpy(Intruder_Attacks,"ERRORR!!");
	strcpy(Intruder_Bites,"ERRORR!!");
	strcpy(Intruder_SVL,"ERRORR!!");
	strcpy(Intruder_ID,"ERRORR!!");
	strcpy(Focal_SVL,"ERRORR!!");

}

class Antipred_CE_Stuff {
/* Name comes from Antipredator Continuous Event Stuff.
	This class is used to extract antipredator
	information from the continuous event recording data. */
	double Time_to_My_Move, Time_Out,Time_Full_Exposure;
	double Hour_hides, Reemergence_hour, Hour_my_approach;
	double Escape_Movement_hour,Hour_1stAttack,Hour_dentro;
	double Full_Exposure_Hour;
	int i;
	int Flag_Speed, Flag_1st_Attack;

public:

	int Flag_Full, Flag_Found, Flag_Antip,
		Flag_Focal, Flag_Intru;
	double Duration_my_Approach,Time_to_Reemergence,Time_to_Full_Exposure,
				Time_to_1stAttack;
	//Antes las flags eran private members, pero es un jaleo
	Antipred_CE_Stuff();
	void Time_Reemergence(const char *behav, const double &hora);
	void Duration_Approach (const char *behav,
				 const double &hora);
	void Time_to_Attack (const char *behav,
				 const double &hora);

};

Antipred_CE_Stuff::Antipred_CE_Stuff()
{
  Flag_Full= -9;
  Flag_Found=0;
  Flag_Antip=Flag_Focal=Flag_Intru=-9;
  Flag_Speed=0;
  Flag_1st_Attack=0;
  Hour_hides= Reemergence_hour=Full_Exposure_Hour=Hour_my_approach= -9999.9;
  Escape_Movement_hour=Hour_1stAttack=Hour_dentro=-9999.9;
  Duration_my_Approach=Time_to_Reemergence=Time_to_Full_Exposure=
  Time_to_1stAttack= -990000.0;

}


/* Gives time to reemergence, and time to full exposure.
Also sets several flags. */

void Antipred_CE_Stuff::Time_Reemergence (const char *behav, const double &hora)
{
	if(Flag_Antip==1) {  //we are in **ANTIP** part
		if(!strcmp(behav,"Lost Lizard       ")) {
			Flag_Found=0;
			Flag_Full=0;
			Hour_hides=hora;
			}
		if(Flag_Found==0) {
			if( (!strcmp(behav,"Found             ")) ||
				 (!strcmp(behav,"Full exposure     ")) ||
				 (!strcmp(behav,"End(1)            ")) ||
				 (!strcmp(behav,"End               ")) )
					{
					Reemergence_hour = hora;
					Flag_Found=1;
					Time_to_Reemergence = Reemergence_hour - Hour_hides;}
			}
		if(Flag_Full==0) {
			if( (!strcmp(behav,"Full exposure     ")) ||
				 (!strcmp(behav,"End(1)            ")) ||
				 (!strcmp(behav,"End               ")) )
					{
					Full_Exposure_Hour=hora;
					Flag_Full=1;
					Time_to_Full_Exposure = Full_Exposure_Hour - Hour_hides;}
			}
	}
}


void Antipred_CE_Stuff::Time_to_Attack (const char *behav, const double &hora)
{
	if(Flag_Intru==1 && Flag_1st_Attack==0) {  //we are in **INTRU** part
		if(!strcmp(behav,"Bicho dentro      ")) Hour_dentro=hora;
		if((!strcmp(behav,"Attack            ")) ||
		   (!strcmp(behav,"Bite              "))) {
			Hour_1stAttack = hora;
			Flag_1st_Attack=1;
			Time_to_1stAttack=Hour_1stAttack-Hour_dentro;
			}
	}
}





void Antipred_CE_Stuff::Duration_Approach (const char *behav, const double &hora)
{
	if(Flag_Antip==1 && Flag_Speed==0) {  //we are in **ANTIP** part
		if(!strcmp(behav,"Start/My move     ")) Hour_my_approach=hora;
		if(!strcmp(behav,"Movement          ")) {
			Escape_Movement_hour = hora;
			Flag_Speed=1;
			Duration_my_Approach=Escape_Movement_hour-Hour_my_approach;
			}
		}
}
